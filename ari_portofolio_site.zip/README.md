
# 🌟 Ari Nurdiansyah | Portfolio

Halo! Saya Ari Nurdiansyah, seorang desainer grafis, ilustrator, dan penulis yang sedang menempuh studi di Universitas Kuningan jurusan Desain Komunikasi Visual.

Ini adalah portofolio online saya yang berisi informasi tentang:
- Layanan yang saya tawarkan
- Karya unggulan
- Pendidikan & keterampilan

## 🎯 Keahlian
- Desain grafis (logo, poster, branding)
- Ilustrasi (dark art, noodle, kartun)
- Pengetikan & editing teks (makalah, jurnal, artikel)

## 📫 Kontak
- Email: anurdiansyah726@gmail.com

---

> Website ini dibangun menggunakan HTML dan di-host secara gratis melalui GitHub Pages.
